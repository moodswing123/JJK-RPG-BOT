const { getSkillEffect } = require("../utils/skills");
const { calculateDamage } = require("../utils/damage");
const { resolveDomainClash } = require("../utils/domainClash");

const activeBattles = global.activeBattles || new Map();

/**
 * 🧠 SAFE DEFAULT PLAYER STATE
 */
function normalizePlayer(p) {
    p.activeDomain = p.activeDomain || null;
    p.status = p.status || [];
    return p;
}

/**
 * ⚔️ MAIN ATTACK ENGINE (OPTIMIZED)
 */
function attack(battleId, attackerId, skillInput) {

    const battle = activeBattles.get(battleId);

    if (!battle || battle.status !== "active") {
        return { error: "❌ Invalid or ended battle." };
    }

    const { p1, p2 } = battle.players;

    const attacker = normalizePlayer(p1.id === attackerId ? p1 : p2);
    const defender = normalizePlayer(p1.id === attackerId ? p2 : p1);

    if (battle.turn !== attackerId) {
        return { error: "❌ Not your turn." };
    }

    const effect = getSkillEffect(skillInput.name);

    // 🌌 DOMAIN ACTIVATION (SAFE)
    if (effect.domain) {
        attacker.activeDomain = effect.domain;

        battle.log.push({
            type: "domain_activate",
            player: attacker.id,
            domain: effect.domain.name
        });
    }

    // ⚔️ DOMAIN CLASH (ONLY IF NEEDED)
    const hasDomain = attacker.activeDomain || defender.activeDomain;

    if (hasDomain) {

        const clash = resolveDomainClash(
            attacker.activeDomain,
            defender.activeDomain
        );

        battle.log.push({
            type: "domain_check",
            a: attacker.activeDomain?.name || null,
            b: defender.activeDomain?.name || null
        });

        if (clash.clash) {

            if (clash.result === "cancelled") {
                attacker.activeDomain = null;
                defender.activeDomain = null;
            }

            if (clash.winner === "A") {
                defender.activeDomain = null;
                battle.domainWinner = attacker.id;
            }

            if (clash.winner === "B") {
                attacker.activeDomain = null;
                battle.domainWinner = defender.id;
            }
        } else {
            battle.domainWinner =
                clash.winner === "A" ? attacker.id :
                clash.winner === "B" ? defender.id : null;
        }
    }

    // ⚔️ DAMAGE CALCULATION (CLEANED)
    const base = effect.damage || 100;

    const result = calculateDamage({
        baseDamage: base,
        strength: attacker.character?.strength || attacker.strength || 10,
        ce: attacker.character?.ce || attacker.ce || 100,
        defense: effect.ignoreDefense
            ? 0
            : (defender.character?.defense || defender.defense || 10),
        critChance: effect.critBoost || 10,
        damageBoost: battle.domainWinner === attacker.id ? 1.3 : 1,
        reduction: effect.reduceDamage || 0
    });

    defender.hp -= result.damage;

    // 🧪 STATUS (SAFE PUSH)
    if (effect.status) {
        defender.status.push({
            type: effect.status.type,
            damage: effect.status.damage || 0,
            turns: effect.status.turns || 1
        });
    }

    // 📝 LOG ATTACK (SIMPLIFIED)
    battle.log.push({
        a: attacker.id,
        d: defender.id,
        skill: skillInput.name,
        dmg: result.damage
    });

    // 🏆 WIN CHECK
    if (defender.hp <= 0) {
        battle.status = "ended";
        battle.winner = attacker.id;

        return {
            winner: attacker.id,
            message: "🏆 Winner declared!"
        };
    }

    // 🔁 TURN SWITCH
    battle.turn = defender.id;

    return {
        damage: result.damage,
        defenderHp: defender.hp,
        nextTurn: defender.id,
        domainWinner: battle.domainWinner || null
    };
}

module.exports = { attack };