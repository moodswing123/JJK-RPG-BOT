function createUser(userId, name = "Unknown Sorcerer") {
    return {
        id: userId,
        name,

        // 📊 Core stats
        level: 1,
        xp: 0,
        hp: 100,
        maxHp: 100,
        ce: 100,
        maxCe: 100,

        strength: 10,
        defense: 10,
        speed: 10,
        luck: 0,

        // 💰 Economy
        yen: 1000,

        // 🎒 Inventory systems
        characters: [],
        tools: [],
        skins: [],
        items: [],
        titles: ["New Sorcerer"],

        // 🏷️ Identity
        clan: "none",
        equippedCharacter: null,
        equippedTool: null,
        equippedTitle: "New Sorcerer",

        // ⚔️ Battle stats
        wins: 0,
        losses: 0,
        streak: 0,

        // ⏱️ Cooldowns / state
        lastDaily: 0,
        lastWeekly: 0,

        // 🧠 Progress tracking
        achievements: {},

        // ⚠️ Status effects
        status: []
    };
}

/**
 * 🔍 Ensure user exists (auto-create system)
 */
function ensureUser(database, userId, name) {

    if (!database[userId]) {
        database[userId] = createUser(userId, name);
    }

    return database[userId];
}

/**
 * 💾 Update user safely
 */
function updateUser(database, userId, updates = {}) {

    if (!database[userId]) return null;

    database[userId] = {
        ...database[userId],
        ...updates
    };

    return database[userId];
}

/**
 * 📊 Reset user battle state
 */
function resetBattleState(user) {

    user.hp = user.maxHp;
    user.status = [];
    user.streak = 0;

    return user;
}

module.exports = {
    createUser,
    ensureUser,
    updateUser,
    resetBattleState
};