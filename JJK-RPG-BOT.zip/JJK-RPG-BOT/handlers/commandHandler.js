const fs = require("fs");

/**
 * 🧠 Command Handler
 * Responsible for parsing and executing all commands
 */

function handleCommand(message, user, commands) {

    const text = message.text || "";

    // ❌ Ignore empty messages
    if (!text.startsWith(".")) {
        return;
    }

    // ✂️ Remove "." prefix
    const argsArray = text.slice(1).trim().split(/ +/g);

    // 📌 Command name
    const commandName = argsArray.shift().toLowerCase();

    // 📌 Remaining args
    const args = argsArray;

    // ⚠️ Check if command exists
    const command = commands[commandName];

    if (!command) {
        return {
            reply: `❌ Unknown command: ${commandName}`
        };
    }

    try {

        // ⚙️ Execute command
        const result = command({
            user,
            args,
            message
        });

        return result;

    } catch (error) {

        console.error("Command Error:", error);

        return {
            reply: "⚠️ An error occurred while executing this command."
        };
    }
}

module.exports = {
    handleCommand
};