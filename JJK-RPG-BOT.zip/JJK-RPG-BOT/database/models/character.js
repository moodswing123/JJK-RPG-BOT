const mongoose = require("mongoose");

const characterSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    rarity: {
        type: String,
        required: true
    },

    price: {
        type: Number,
        default: 0
    },

    premium: {
        type: Boolean,
        default: false
    },

    clan: {
        type: String,
        default: "None"
    },

    grade: {
        type: String,
        default: "Grade 4"
    },

    hp: {
        type: Number,
        default: 1000
    },

    cursedEnergy: {
        type: Number,
        default: 500
    },

    strength: {
        type: Number,
        default: 10
    },

    defense: {
        type: Number,
        default: 10
    },

    speed: {
        type: Number,
        default: 10
    },

    luck: {
        type: Number,
        default: 5
    },

    battlePower: {
        type: Number,
        default: 100
    },

    passive: {
        type: String,
        default: ""
    },

    ultimate: {
        type: String,
        default: ""
    },

    domainExpansion: {
        type: String,
        default: ""
    },

    skills: {
        type: [String],
        default: []
    },

    cursedTool: {
        type: String,
        default: ""
    },

    description: {
        type: String,
        default: ""
    },

    image: {
        type: String,
        default: ""
    }

}, {
    timestamps: true
});

module.exports = mongoose.model("Character", characterSchema);