const mongoose = require("mongoose");

const clanSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    rarity: {
        type: String,
        default: "Common"
    },

    chance: {
        type: Number,
        default: 100
    },

    price: {
        type: Number,
        default: 0
    },

    premium: {
        type: Boolean,
        default: false
    },

    hpBonus: {
        type: Number,
        default: 0
    },

    ceBonus: {
        type: Number,
        default: 0
    },

    strengthBonus: {
        type: Number,
        default: 0
    },

    defenseBonus: {
        type: Number,
        default: 0
    },

    speedBonus: {
        type: Number,
        default: 0
    },

    luckBonus: {
        type: Number,
        default: 0
    },

    passive: {
        type: String,
        default: ""
    },

    description: {
        type: String,
        default: ""
    },

    exclusiveSkills: {
        type: [String],
        default: []
    },

    exclusiveCharacters: {
        type: [String],
        default: []
    },

    image: {
        type: String,
        default: ""
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Clan", clanSchema);