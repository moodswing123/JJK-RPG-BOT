const mongoose = require("mongoose");

const questSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    description: {
        type: String,
        default: ""
    },

    category: {
        type: String,
        default: "Daily"
    },

    difficulty: {
        type: String,
        default: "Easy"
    },

    requiredLevel: {
        type: Number,
        default: 1
    },

    objective: {
        type: String,
        default: ""
    },

    target: {
        type: Number,
        default: 1
    },

    rewardXP: {
        type: Number,
        default: 0
    },

    rewardYen: {
        type: Number,
        default: 0
    },

    rewardCharacter: {
        type: String,
        default: ""
    },

    rewardTool: {
        type: String,
        default: ""
    },

    rewardSkin: {
        type: String,
        default: ""
    },

    rewardTitle: {
        type: String,
        default: ""
    },

    repeatable: {
        type: Boolean,
        default: false
    },

    timeLimit: {
        type: Number,
        default: 0
    },

    active: {
        type: Boolean,
        default: true
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Quest", questSchema);