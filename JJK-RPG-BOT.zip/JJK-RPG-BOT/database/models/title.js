const mongoose = require("mongoose");

const titleSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    rarity: {
        type: String,
        default: "Common"
    },

    description: {
        type: String,
        default: ""
    },

    unlockRequirement: {
        type: String,
        default: ""
    },

    color: {
        type: String,
        default: "#FFFFFF"
    },

    profileEffect: {
        type: String,
        default: ""
    },

    battleEntrance: {
        type: String,
        default: ""
    },

    hpBonus: {
        type: Number,
        default: 0
    },

    ceBonus: {
        type: Number,
        default: 0
    },

    strengthBonus: {
        type: Number,
        default: 0
    },

    defenseBonus: {
        type: Number,
        default: 0
    },

    speedBonus: {
        type: Number,
        default: 0
    },

    luckBonus: {
        type: Number,
        default: 0
    },

    premium: {
        type: Boolean,
        default: false
    },

    limited: {
        type: Boolean,
        default: false
    },

    image: {
        type: String,
        default: ""
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Title", titleSchema);