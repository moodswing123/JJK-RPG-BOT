const mongoose = require("mongoose");

const skillSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    character: {
        type: String,
        required: true
    },

    type: {
        type: String,
        default: "Attack"
    },

    rarity: {
        type: String,
        default: "Common"
    },

    damage: {
        type: Number,
        default: 100
    },

    ceCost: {
        type: Number,
        default: 0
    },

    cooldown: {
        type: Number,
        default: 0
    },

    accuracy: {
        type: Number,
        default: 100
    },

    criticalChance: {
        type: Number,
        default: 5
    },

    unlockLevel: {
        type: Number,
        default: 1
    },

    description: {
        type: String,
        default: ""
    },

    passive: {
        type: Boolean,
        default: false
    },

    ultimate: {
        type: Boolean,
        default: false
    },

    domainExpansion: {
        type: Boolean,
        default: false
    },

    battleMessage: {
        type: String,
        default: ""
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Skill", skillSchema);