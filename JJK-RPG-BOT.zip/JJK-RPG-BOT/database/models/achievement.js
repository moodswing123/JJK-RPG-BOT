const mongoose = require("mongoose");

const achievementSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    description: {
        type: String,
        default: ""
    },

    category: {
        type: String,
        default: "General"
    },

    rarity: {
        type: String,
        default: "Common"
    },

    requirement: {
        type: String,
        default: ""
    },

    target: {
        type: Number,
        default: 1
    },

    rewardXP: {
        type: Number,
        default: 0
    },

    rewardYen: {
        type: Number,
        default: 0
    },

    rewardCharacter: {
        type: String,
        default: ""
    },

    rewardSkin: {
        type: String,
        default: ""
    },

    rewardTool: {
        type: String,
        default: ""
    },

    rewardTitle: {
        type: String,
        default: ""
    },

    hidden: {
        type: Boolean,
        default: false
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Achievement", achievementSchema);