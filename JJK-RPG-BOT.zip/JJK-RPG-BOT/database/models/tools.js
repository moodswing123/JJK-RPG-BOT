const mongoose = require("mongoose");

const toolSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    rarity: {
        type: String,
        default: "Common"
    },

    type: {
        type: String,
        default: "Weapon"
    },

    owner: {
        type: String,
        default: "None"
    },

    price: {
        type: Number,
        default: 0
    },

    damage: {
        type: Number,
        default: 100
    },

    hpBonus: {
        type: Number,
        default: 0
    },

    ceBonus: {
        type: Number,
        default: 0
    },

    strengthBonus: {
        type: Number,
        default: 0
    },

    defenseBonus: {
        type: Number,
        default: 0
    },

    speedBonus: {
        type: Number,
        default: 0
    },

    criticalBonus: {
        type: Number,
        default: 0
    },

    durability: {
        type: Number,
        default: 100
    },

    maxDurability: {
        type: Number,
        default: 100
    },

    passive: {
        type: String,
        default: ""
    },

    description: {
        type: String,
        default: ""
    },

    image: {
        type: String,
        default: ""
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Tool", toolSchema);