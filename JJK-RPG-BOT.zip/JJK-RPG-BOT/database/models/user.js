const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
{
    // ==========================
    // BASIC INFORMATION
    // ==========================

    userId: {
        type: String,
        required: true,
        unique: true
    },

    username: {
        type: String,
        default: "Unknown Sorcerer"
    },

    registered: {
        type: Boolean,
        default: false
    },

    // ==========================
    // CHARACTER
    // ==========================

    character: {
        type: String,
        default: "Starter Sorcerer"
    },

    clan: {
        type: String,
        default: "None"
    },

    grade: {
        type: String,
        default: "Grade 4"
    },

    level: {
        type: Number,
        default: 1
    },

    xp: {
        type: Number,
        default: 0
    },

    // ==========================
    // STATS
    // ==========================

    hp: {
        type: Number,
        default: 1000
    },

    maxHp: {
        type: Number,
        default: 1000
    },

    cursedEnergy: {
        type: Number,
        default: 500
    },

    maxCursedEnergy: {
        type: Number,
        default: 500
    },

    strength: {
        type: Number,
        default: 10
    },

    defense: {
        type: Number,
        default: 10
    },

    speed: {
        type: Number,
        default: 10
    },

    luck: {
        type: Number,
        default: 5
    },

    battlePower: {
        type: Number,
        default: 100
    },

    // ==========================
    // ECONOMY
    // ==========================

    wallet: {
        type: Number,
        default: 5000
    },

    bank: {
        type: Number,
        default: 0
    },

    // ==========================
    // EQUIPMENT
    // ==========================

    inventory: {
        type: [String],
        default: []
    },

    backpack: {
        type: [String],
        default: []
    },

    cursedTools: {
        type: [String],
        default: []
    },

    equippedTool: {
        type: String,
        default: null
    },

    skins: {
        type: [String],
        default: []
    },

    titles: {
        type: [String],
        default: []
    },

    skills: {
        type: [String],
        default: []
    },

    // ==========================
    // BATTLE
    // ==========================

    pvpWins: {
        type: Number,
        default: 0
    },

    pvpLosses: {
        type: Number,
        default: 0
    },

    bossKills: {
        type: Number,
        default: 0
    },

    // ==========================
    // GAME PROGRESS
    // ==========================

    achievements: {
        type: [String],
        default: []
    },

    quests: {
        type: [String],
        default: []
    },

    // ==========================
    // COOLDOWNS
    // ==========================

    cooldowns: {
        daily: {
            type: Number,
            default: 0
        },

        weekly: {
            type: Number,
            default: 0
        },

        work: {
            type: Number,
            default: 0
        },

        training: {
            type: Number,
            default: 0
        }
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("User", userSchema);