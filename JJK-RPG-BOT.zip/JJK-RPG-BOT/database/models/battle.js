const mongoose = require("mongoose");

const battleSchema = new mongoose.Schema({

    battleId: {
        type: String,
        required: true,
        unique: true
    },

    battleType: {
        type: String,
        default: "PvP"
    },

    playerOne: {
        type: String,
        required: true
    },

    playerTwo: {
        type: String,
        required: true
    },

    playerOneCharacter: {
        type: String,
        default: ""
    },

    playerTwoCharacter: {
        type: String,
        default: ""
    },

    playerOneHP: {
        type: Number,
        default: 1000
    },

    playerTwoHP: {
        type: Number,
        default: 1000
    },

    playerOneCE: {
        type: Number,
        default: 500
    },

    playerTwoCE: {
        type: Number,
        default: 500
    },

    playerOneStatus: {
        type: [String],
        default: []
    },

    playerTwoStatus: {
        type: [String],
        default: []
    },

    currentTurn: {
        type: String,
        default: ""
    },

    currentRound: {
        type: Number,
        default: 1
    },

    winner: {
        type: String,
        default: ""
    },

    loser: {
        type: String,
        default: ""
    },

    battleLog: {
        type: [String],
        default: []
    },

    finished: {
        type: Boolean,
        default: false
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Battle", battleSchema);