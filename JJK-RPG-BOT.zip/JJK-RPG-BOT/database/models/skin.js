const mongoose = require("mongoose");

const skinSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true,
        unique: true
    },

    character: {
        type: String,
        required: true
    },

    rarity: {
        type: String,
        default: "Common"
    },

    type: {
        type: String,
        default: "Sorcerer"
    },

    price: {
        type: Number,
        default: 0
    },

    premium: {
        type: Boolean,
        default: false
    },

    limited: {
        type: Boolean,
        default: false
    },

    event: {
        type: String,
        default: ""
    },

    hpBonus: {
        type: Number,
        default: 0
    },

    ceBonus: {
        type: Number,
        default: 0
    },

    strengthBonus: {
        type: Number,
        default: 0
    },

    defenseBonus: {
        type: Number,
        default: 0
    },

    speedBonus: {
        type: Number,
        default: 0
    },

    luckBonus: {
        type: Number,
        default: 0
    },

    passive: {
        type: String,
        default: ""
    },

    battleEffect: {
        type: String,
        default: ""
    },

    profileEffect: {
        type: String,
        default: ""
    },

    description: {
        type: String,
        default: ""
    },

    image: {
        type: String,
        default: ""
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Skin", skinSchema);