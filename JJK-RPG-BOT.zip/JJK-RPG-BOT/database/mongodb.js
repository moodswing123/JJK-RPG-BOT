const mongoose = require("mongoose");
const chalk = require("chalk");
require("dotenv").config();

async function connectDatabase() {
    try {
        mongoose.set("strictQuery", true);

        await mongoose.connect(process.env.MONGO_URI);

        console.log(chalk.green("===================================="));
        console.log(chalk.green("✓ MongoDB Connected Successfully"));
        console.log(chalk.green("Database:", mongoose.connection.name));
        console.log(chalk.green("===================================="));

    } catch (error) {

        console.error(chalk.red("===================================="));
        console.error(chalk.red("❌ MongoDB Connection Failed"));
        console.error(chalk.red(error.message));
        console.error(chalk.red("===================================="));

        process.exit(1);
    }
}

module.exports = connectDatabase;