const { getCharacter } = require("./characters");
const { updateUser } = require("./db");

/**
 * 🌌 AWAKEN CHARACTER (ONLY 3 ALLOWED)
 */
function awakenCharacter(userId, characterId, user) {

    const allowed = ["gojo", "sukuna", "itadori"];

    if (!allowed.includes(characterId)) {
        return { error: "❌ This character cannot awaken." };
    }

    const character = getCharacter(characterId);

    if (!character) {
        return { error: "❌ Character not found." };
    }

    if (user.character?.id !== characterId) {
        return { error: "❌ You must equip this character first." };
    }

    if (user.character?.awakened) {
        return { error: "❌ Already awakened." };
    }

    const aw = character.awakening;

    // ⚡ APPLY BOOSTS
    const updatedCharacter = {
        ...user.character,
        awakened: true,
        awakeningName: aw.name,
        hp: user.character.hp + aw.hpBoost,
        strength: user.character.strength + aw.strengthBoost,
        defense: user.character.defense + aw.defenseBoost,
        ce: user.character.ce + aw.ceBoost
    };

    updateUser(userId, {
        character: updatedCharacter
    });

    return {
        success: true,
        message: `
🌌 *AWAKENING COMPLETE!*

👤 ${character.name}
⚡ Form: ${aw.name}

❤️ HP +${aw.hpBoost}
💥 STR +${aw.strengthBoost}
🛡 DEF +${aw.defenseBoost}
⚡ CE +${aw.ceBoost}

🔥 You have reached a new level of power!
`
    };
}

module.exports = {
    awakenCharacter
};