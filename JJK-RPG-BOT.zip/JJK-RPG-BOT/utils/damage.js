function calculateDamage({
    baseDamage = 0,
    strength = 0,
    ce = 0,
    defense = 0,
    critChance = 0,
    critMultiplier = 2,
    damageBoost = 0,
    reduction = 0
}) {

    // 🔥 Power scaling (strength + cursed energy influence)
    let rawDamage = baseDamage + (strength * 1.5) + (ce * 0.2);

    // ⚡ Apply global damage boost (skills, clans, buffs)
    rawDamage = rawDamage * (1 + damageBoost);

    // 🎯 Critical hit check
    const critRoll = Math.random() * 100;
    let isCrit = false;

    if (critRoll < critChance) {
        rawDamage *= critMultiplier;
        isCrit = true;
    }

    // 🛡️ Defense reduction formula
    const defenseReduction = defense * 0.8;
    rawDamage = rawDamage - defenseReduction;

    // 🧊 Final damage reduction (passives, tools, buffs)
    rawDamage = rawDamage * (1 - reduction);

    // ❌ Prevent negative damage
    if (rawDamage < 1) rawDamage = 1;

    return {
        damage: Math.floor(rawDamage),
        isCrit
    };
}

module.exports = { calculateDamage };