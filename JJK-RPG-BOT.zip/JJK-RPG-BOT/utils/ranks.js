const ranks = [
    { name: "Genin", min: 0 },
    { name: "Chunin", min: 100 },
    { name: "Jounin", min: 300 },
    { name: "Elite", min: 600 },
    { name: "Special Grade", min: 1000 }
];

/**
 * 🧠 Get rank from RP
 */
function getRank(rp) {
    let current = ranks[0];

    for (const rank of ranks) {
        if (rp >= rank.min) {
            current = rank;
        }
    }

    return current.name;
}

/**
 * ⚡ Add RP after battle
 */
function addRP(user, amount) {

    const newRP = (user.rp || 0) + amount;
    const newRank = getRank(newRP);

    return {
        rp: newRP,
        rank: newRank
    };
}

module.exports = {
    getRank,
    addRP
};