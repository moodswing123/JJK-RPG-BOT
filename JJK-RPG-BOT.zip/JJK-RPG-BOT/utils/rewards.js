const fs = require("fs");

// 🎲 Random number helper
function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// 🎁 Basic reward giver (XP + Yen + items)
function giveReward(user, reward = {}) {

    if (!user) return user;

    // 💰 Yen reward
    if (reward.yen) {
        user.yen = (user.yen || 0) + reward.yen;
    }

    // ⭐ XP reward
    if (reward.xp) {
        user.xp = (user.xp || 0) + reward.xp;
    }

    // 👤 Character reward
    if (reward.character) {
        user.characters = user.characters || [];
        if (!user.characters.includes(reward.character)) {
            user.characters.push(reward.character);
        }
    }

    // 🗡️ Tool reward
    if (reward.tool) {
        user.tools = user.tools || [];
        user.tools.push(reward.tool);
    }

    // 👕 Skin reward
    if (reward.skin) {
        user.skins = user.skins || [];
        user.skins.push(reward.skin);
    }

    // 🏆 Title reward
    if (reward.title) {
        user.titles = user.titles || [];
        if (!user.titles.includes(reward.title)) {
            user.titles.push(reward.title);
        }
    }

    return user;
}

// 🎯 Drop system (chance-based rewards)
function rollDrop(dropTable = []) {

    if (!dropTable.length) return null;

    const roll = Math.random();

    let cumulative = 0;

    for (const item of dropTable) {
        cumulative += item.chance;

        if (roll <= cumulative) {
            return item.reward;
        }
    }

    return null;
}

// 🧪 Boss reward calculator
function bossRewards(boss) {

    const baseXP = boss.rewards?.xp || 0;
    const baseYen = boss.rewards?.yen || 0;

    return {
        xp: rand(baseXP * 0.8, baseXP * 1.2),
        yen: rand(baseYen * 0.8, baseYen * 1.2)
    };
}

// 🎁 Quest reward generator
function questRewards(quest) {

    return {
        xp: quest.rewardXP || 0,
        yen: quest.rewardYen || 0,
        character: quest.rewardCharacter || null,
        tool: quest.rewardTool || null,
        skin: quest.rewardSkin || null,
        title: quest.rewardTitle || null
    };
}

module.exports = {
    rand,
    giveReward,
    rollDrop,
    bossRewards,
    questRewards
};