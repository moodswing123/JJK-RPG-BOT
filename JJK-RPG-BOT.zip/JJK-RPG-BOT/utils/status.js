function applyStatus(user, status) {

    if (!user.status) user.status = [];

    user.status.push({
        name: status.name,
        type: status.type,
        duration: status.duration,
        value: status.value || 0
    });

    return user;
}

/**
 * ⚡ Process status effects each turn
 */
function processStatus(user) {

    if (!user.status || user.status.length === 0) {
        return { user, log: [] };
    }

    let log = [];

    user.status = user.status.filter(effect => {

        switch (effect.type) {

            case "burn":
                user.hp -= effect.value;
                log.push(`🔥 Burn deals ${effect.value} damage`);
                break;

            case "bleed":
                user.hp -= effect.value;
                log.push(`🩸 Bleed drains ${effect.value} HP`);
                break;

            case "heal_block":
                log.push(`🚫 Healing is blocked`);
                break;

            case "stun":
                log.push(`⚡ Stunned! Turn skipped`);
                break;

            case "seal":
                log.push(`🔒 Skills sealed`);
                break;
        }

        effect.duration -= 1;

        // ❌ Remove expired effects
        return effect.duration > 0;
    });

    return { user, log };
}

/**
 * 🚫 Check if user is stunned
 */
function isStunned(user) {
    return user.status?.some(s => s.type === "stun");
}

/**
 * 🔒 Check if skills are sealed
 */
function isSealed(user) {
    return user.status?.some(s => s.type === "seal");
}

module.exports = {
    applyStatus,
    processStatus,
    isStunned,
    isSealed
};