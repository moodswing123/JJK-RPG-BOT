function resolveDomainClash(domainA, domainB) {

    // 🌌 If only one domain exists
    if (!domainA && !domainB) {
        return {
            clash: false
        };
    }

    if (domainA && !domainB) {
        return {
            clash: false,
            winner: "A"
        };
    }

    if (!domainA && domainB) {
        return {
            clash: false,
            winner: "B"
        };
    }

    // ⚔️ BOTH DOMAINS ACTIVE → CLASH MODE
    const powerA = domainA.power || 50;
    const powerB = domainB.power || 50;

    let result = {
        clash: true,
        result: null,
        winner: null,
        loser: null
    };

    // 🥇 A WINS CLASH
    if (powerA > powerB) {
        result.result = "A_wins";
        result.winner = "A";
        result.loser = "B";
    }

    // 🥇 B WINS CLASH
    else if (powerB > powerA) {
        result.result = "B_wins";
        result.winner = "B";
        result.loser = "A";
    }

    // ⚖️ PERFECT TIE → BOTH CANCEL
    else {
        result.result = "cancelled";
        result.winner = null;
        result.loser = null;
    }

    return result;
}

module.exports = {
    resolveDomainClash
};