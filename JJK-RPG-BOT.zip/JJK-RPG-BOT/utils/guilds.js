const fs = require("fs");

const GUILD_PATH = "./data/guilds.json";

function loadGuilds() {
    if (!fs.existsSync(GUILD_PATH)) {
        fs.writeFileSync(GUILD_PATH, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(GUILD_PATH));
}

function saveGuilds(data) {
    fs.writeFileSync(GUILD_PATH, JSON.stringify(data, null, 2));
}

/**
 * 🏰 CREATE GUILD
 */
function createGuild(user, name) {

    const db = loadGuilds();

    const id = `guild_${Date.now()}`;

    db[id] = {
        id,
        name,
        owner: user.id,
        members: [user.id],
        level: 1,
        xp: 0,
        wins: 0,
        losses: 0
    };

    saveGuilds(db);

    return id;
}

/**
 * ➕ JOIN GUILD
 */
function joinGuild(user, guildId) {

    const db = loadGuilds();
    const guild = db[guildId];

    if (!guild) return { error: "❌ Guild not found." };

    if (guild.members.includes(user.id)) {
        return { error: "❌ Already in guild." };
    }

    guild.members.push(user.id);

    saveGuilds(db);

    return { success: true };
}

/**
 * 🚪 LEAVE GUILD
 */
function leaveGuild(user, guildId) {

    const db = loadGuilds();
    const guild = db[guildId];

    if (!guild) return { error: "❌ Guild not found." };

    guild.members = guild.members.filter(m => m !== user.id);

    saveGuilds(db);

    return { success: true };
}

/**
 * 📊 GET GUILD
 */
function getGuild(guildId) {
    const db = loadGuilds();
    return db[guildId];
}

module.exports = {
    createGuild,
    joinGuild,
    leaveGuild,
    getGuild
};