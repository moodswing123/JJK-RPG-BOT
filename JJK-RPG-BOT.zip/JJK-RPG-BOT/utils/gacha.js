const { randomCharacter } = require("./characters");

/**
 * 🎰 Rarity chances
 */
function getRarity() {
    const roll = Math.random() * 100;

    if (roll < 5) return "special";     // 5%
    if (roll < 20) return "rare";       // 15%
    return "common";                    // 80%
}

/**
 * 🎲 Pull character
 */
function pullCharacter() {
    const character = randomCharacter();
    const rarity = getRarity();

    return {
        ...character,
        pulledRarity: rarity
    };
}

module.exports = {
    pullCharacter
};