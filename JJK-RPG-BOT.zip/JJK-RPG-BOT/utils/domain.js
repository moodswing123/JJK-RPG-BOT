const { applyStatus } = require("./status");

/**
 * 🌌 Activate Domain Expansion
 */
function activateDomain(user, domain) {

    if (!user.domainCooldown) user.domainCooldown = 0;

    // ⏱ cooldown check (optional logic layer)
    if (Date.now() < user.domainCooldown) {
        return {
            success: false,
            message: "❌ Domain is on cooldown."
        };
    }

    let effect = {
        damageBoost: 0.5,
        guaranteedHit: true,
        status: null
    };

    // 🌟 DOMAIN TYPES
    switch (domain) {

        case "infinite_void":
            effect.damageBoost = 1.2;
            effect.status = {
                name: "Infinite Stun",
                type: "stun",
                duration: 1,
                value: 0
            };
            break;

        case "malevolent_shrine":
            effect.damageBoost = 1.5;
            effect.status = {
                name: "Cleave Bleed",
                type: "bleed",
                duration: 3,
                value: 40
            };
            break;

        case "hollow_purple_domain":
            effect.damageBoost = 2;
            effect.status = {
                name: "Erasure Burn",
                type: "burn",
                duration: 2,
                value: 60
            };
            break;

        default:
            return {
                success: false,
                message: "❌ Unknown domain."
            };
    }

    // ⏱ set cooldown (very long cooldown = balanced gameplay)
    user.domainCooldown = Date.now() + 120000; // 2 minutes

    // 🔒 apply status effect if exists
    if (effect.status) {
        user = applyStatus(user, effect.status);
    }

    return {
        success: true,
        user,
        effect,
        message: `🌌 ${domain.replace(/_/g, " ").toUpperCase()} ACTIVATED!`
    };
}

/**
 * ⚔️ Domain damage enhancer
 */
function applyDomainBoost(damage, effect) {
    return Math.floor(damage * (1 + effect.damageBoost));
}

module.exports = {
    activateDomain,
    applyDomainBoost
};