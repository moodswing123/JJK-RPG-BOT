const tournaments = new Map();

/**
 * 🏆 CREATE TOURNAMENT
 */
function createTournament(name) {

    const id = `tourney_${Date.now()}`;

    tournaments.set(id, {
        id,
        name,
        players: [],
        bracket: [],
        round: 1,
        status: "waiting",
        winner: null
    });

    return id;
}

/**
 * ➕ JOIN TOURNAMENT
 */
function joinTournament(tournamentId, user) {

    const tourney = tournaments.get(tournamentId);

    if (!tourney) return { error: "❌ Tournament not found." };

    if (tourney.status !== "waiting") {
        return { error: "❌ Tournament already started." };
    }

    if (tourney.players.find(p => p.id === user.id)) {
        return { error: "❌ Already joined." };
    }

    tourney.players.push(user);

    return { success: true };
}

/**
 * ⚔️ START TOURNAMENT
 */
function startTournament(tournamentId) {

    const tourney = tournaments.get(tournamentId);

    if (!tourney) return { error: "❌ Not found." };

    if (tourney.players.length < 2) {
        return { error: "❌ Not enough players." };
    }

    tourney.status = "active";

    // 🎲 shuffle players
    const shuffled = tourney.players.sort(() => Math.random() - 0.5);

    const pairs = [];

    for (let i = 0; i < shuffled.length; i += 2) {
        if (shuffled[i + 1]) {
            pairs.push([shuffled[i], shuffled[i + 1]]);
        }
    }

    tourney.bracket = pairs;

    return { success: true, bracket: pairs };
}

/**
 * 🏆 RESOLVE MATCH
 */
function resolveMatch(tournamentId, winnerId) {

    const tourney = tournaments.get(tournamentId);

    if (!tourney) return;

    // remove losers
    tourney.bracket = tourney.bracket
        .map(match => match.find(p => p.id === winnerId))
        .filter(Boolean);

    // next round check
    if (tourney.bracket.length === 1) {
        tourney.winner = tourney.bracket[0].id;
        tourney.status = "ended";
    }

    tourney.round += 1;
}

/**
 * 📊 GET TOURNAMENT
 */
function getTournament(id) {
    return tournaments.get(id);
}

module.exports = {
    createTournament,
    joinTournament,
    startTournament,
    resolveMatch,
    getTournament
};