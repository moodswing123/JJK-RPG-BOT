const fs = require("fs");

const DB_PATH = "./data/users.json";

/**
 * 📥 Load DB
 */
function loadDB() {
    if (!fs.existsSync(DB_PATH)) {
        fs.writeFileSync(DB_PATH, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(DB_PATH));
}

/**
 * 💾 Save DB
 */
function saveDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

/**
 * 👤 GET USER (AUTO INITIALIZED RPG PROFILE)
 */
function getUser(id, name = "Player") {

    const db = loadDB();

    if (!db[id]) {
        db[id] = {
            id,
            name,

            // 💰 ECONOMY
            yen: 1000,

            // ⚔️ BASE STATS
            hp: 100,
            maxHp: 100,
            ce: 100,
            strength: 10,
            defense: 10,
            speed: 10,

            // 🎴 CHARACTER SYSTEM
            character: null,
            characters: [],

            // 🎒 INVENTORY
            tools: [],
            skins: [],
            items: [],
            titles: [],

            // ⚙️ EQUIP SYSTEM
            equippedTool: null,
            equippedTitle: null,

            // 🧠 STATUS SYSTEM
            status: [],

            // 🏆 RANK SYSTEM
            rank: "Genin",
            rp: 0,
            wins: 0,
            losses: 0,

            // 🏰 GUILD SYSTEM (NEW)
            guild: null,
            guildRole: null,

            // 🌌 AWAKENING TRACKING
            awakened: false,

            // 📊 META (FUTURE SAFE)
            createdAt: Date.now()
        };

        saveDB(db);
    }

    return db[id];
}

/**
 * ✏️ UPDATE USER
 */
function updateUser(id, updateData) {

    const db = loadDB();

    if (!db[id]) return;

    db[id] = {
        ...db[id],
        ...updateData
    };

    saveDB(db);
}

module.exports = {
    getUser,
    updateUser
};