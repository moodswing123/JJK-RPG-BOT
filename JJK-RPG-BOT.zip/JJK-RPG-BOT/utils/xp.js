function getXPForLevel(level) {
    // 📈 Exponential scaling so levels get harder over time
    return Math.floor(100 * Math.pow(level, 1.6));
}

function addXP(user, gainedXP) {
    if (!user) return user;

    user.xp = (user.xp || 0) + gainedXP;

    let levelUps = 0;

    // 🔁 Loop in case multiple level-ups happen at once
    while (user.xp >= getXPForLevel(user.level)) {
        user.xp -= getXPForLevel(user.level);
        user.level += 1;
        levelUps += 1;

        // 🎁 Small rewards per level up
        user.yen += 1000 * user.level;
        user.ce += 50 * user.level;
    }

    return {
        user,
        levelUps
    };
}

function getRank(level) {

    if (level >= 100) return "Special Grade";
    if (level >= 80) return "Grade 1";
    if (level >= 60) return "Grade 2";
    if (level >= 40) return "Grade 3";
    if (level >= 20) return "Grade 4";
    return "New Sorcerer";
}

function getLevelProgress(user) {

    const currentXP = user.xp || 0;
    const requiredXP = getXPForLevel(user.level);

    return {
        level: user.level,
        currentXP,
        requiredXP,
        progress: Math.floor((currentXP / requiredXP) * 100)
    };
}

module.exports = {
    getXPForLevel,
    addXP,
    getRank,
    getLevelProgress
};