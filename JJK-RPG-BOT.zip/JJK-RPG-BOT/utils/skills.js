function getSkillEffect(skillName) {

    const skill = skillName.toLowerCase();

    const skills = {

        // 🌌 GOJO SATORU
        hollow_purple: {
            damage: 250,
            ignoreDefense: true,
            critBoost: 30
        },

        infinity: {
            damage: 0,
            reduceDamage: 80,
            status: {
                type: "shield",
                turns: 1
            }
        },

        blue: {
            damage: 120,
            status: {
                type: "stun",
                turns: 1
            }
        },

        red: {
            damage: 150,
            status: {
                type: "bleed",
                damage: 20,
                turns: 2
            }
        },

        // 🌌 GOJO DOMAIN (IMPORTANT UPDATE)
        infinite_void: {
            damage: 0,
            domain: {
                name: "Infinite Void",
                effect: "stun_all",
                power: 90,          // ⚔️ DOMAIN CLASH POWER
                turns: 2
            },
            status: {
                type: "stun",
                turns: 2
            }
        },

        // 👹 SUKUNA
        cleave: {
            damage: 200,
            ignoreDefense: true
        },

        dismantle: {
            damage: 170,
            status: {
                type: "bleed",
                damage: 15,
                turns: 3
            }
        },

        // 👹 SUKUNA DOMAIN (IMPORTANT UPDATE)
        malevolent_shrine: {
            damage: 300,
            ignoreDefense: true,
            status: {
                type: "burn",
                damage: 25,
                turns: 3
            },
            domain: {
                name: "Malevolent Shrine",
                effect: "guaranteed_hits",
                power: 100,        // ⚔️ HIGHER POWER THAN GOJO
                turns: 2
            }
        },

        // 🥷 ITADORI
        black_flash: {
            damage: 180,
            critBoost: 40
        },

        punch: {
            damage: 100
        }
    };

    return skills[skill] || skills.punch;
}

module.exports = {
    getSkillEffect
};