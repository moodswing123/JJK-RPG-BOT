const cooldowns = new Map();

/**
 * ⏱ Set cooldown for a user action
 */
function setCooldown(userId, command, seconds) {
    if (!cooldowns.has(userId)) {
        cooldowns.set(userId, {});
    }

    const userCooldowns = cooldowns.get(userId);

    userCooldowns[command] = Date.now() + seconds * 1000;

    cooldowns.set(userId, userCooldowns);
}

/**
 * ❌ Check if user is on cooldown
 */
function isOnCooldown(userId, command) {
    if (!cooldowns.has(userId)) return false;

    const userCooldowns = cooldowns.get(userId);

    if (!userCooldowns[command]) return false;

    return Date.now() < userCooldowns[command];
}

/**
 * ⏳ Get remaining cooldown time
 */
function getCooldownTime(userId, command) {
    if (!cooldowns.has(userId)) return 0;

    const userCooldowns = cooldowns.get(userId);

    if (!userCooldowns[command]) return 0;

    const remaining = userCooldowns[command] - Date.now();

    return remaining > 0 ? Math.ceil(remaining / 1000) : 0;
}

/**
 * 🧹 Clean expired cooldowns (prevents memory leak)
 */
function cleanCooldowns() {
    const now = Date.now();

    for (const [userId, commands] of cooldowns.entries()) {
        for (const cmd in commands) {
            if (commands[cmd] < now) {
                delete commands[cmd];
            }
        }

        // remove empty user entries
        if (Object.keys(commands).length === 0) {
            cooldowns.delete(userId);
        }
    }
}

module.exports = {
    setCooldown,
    isOnCooldown,
    getCooldownTime,
    cleanCooldowns
};