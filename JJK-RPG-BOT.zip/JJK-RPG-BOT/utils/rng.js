const fs = require("fs");

/**
 * 🎲 Basic random number helper
 */
function rand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * 🎯 Weighted random picker (core gacha system)
 */
function weightedRandom(items = []) {

    if (!items.length) return null;

    let totalWeight = 0;

    for (const item of items) {
        totalWeight += item.weight;
    }

    let roll = Math.random() * totalWeight;

    for (const item of items) {
        if (roll < item.weight) {
            return item.value;
        }
        roll -= item.weight;
    }

    return null;
}

/**
 * 🎰 Rarity roll system (used for summons / drops)
 */
function rollRarity(luck = 0) {

    const baseRates = {
        common: 60,
        rare: 25,
        epic: 10,
        legendary: 4,
        mythic: 0.9,
        divine: 0.1
    };

    // 🍀 Luck slightly improves high-tier chances
    const modifier = Math.min(luck * 0.01, 5);

    const adjustedRates = {
        common: baseRates.common - modifier,
        rare: baseRates.rare,
        epic: baseRates.epic + modifier / 2,
        legendary: baseRates.legendary + modifier / 2,
        mythic: baseRates.mythic + modifier / 4,
        divine: baseRates.divine + modifier / 10
    };

    const roll = Math.random() * 100;
    let cumulative = 0;

    for (const [rarity, chance] of Object.entries(adjustedRates)) {
        cumulative += chance;
        if (roll <= cumulative) return rarity;
    }

    return "common";
}

/**
 * 🎁 Gacha pull (characters / skins / tools)
 */
function gachaPull(pool = [], luck = 0) {

    const rarity = rollRarity(luck);

    const filtered = pool.filter(item => item.rarity === rarity);

    if (!filtered.length) {
        return pool[rand(0, pool.length - 1)];
    }

    return filtered[rand(0, filtered.length - 1)];
}

/**
 * ⚔️ Critical hit roll (for battle system)
 */
function critRoll(critChance = 5) {
    return Math.random() * 100 < critChance;
}

/**
 * 📦 Drop chance system (boss rewards / loot tables)
 */
function dropChance(chance = 0.5) {
    return Math.random() < chance;
}

module.exports = {
    rand,
    weightedRandom,
    rollRarity,
    gachaPull,
    critRoll,
    dropChance
};