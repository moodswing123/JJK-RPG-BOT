const { awakenCharacter } = require("../utils/awakening");

module.exports = async ({ user, args }) => {

    const charId = args[0];

    if (!charId) {
        return {
            reply: "❌ Usage: .awaken <gojo|sukuna|itadori>"
        };
    }

    const result = awakenCharacter(user.id, charId, user);

    if (result.error) {
        return { reply: result.error };
    }

    return { reply: result.message };
};