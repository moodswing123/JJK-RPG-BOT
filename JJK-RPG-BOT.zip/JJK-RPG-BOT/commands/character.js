const { getCharacter } = require("../utils/characters");
const { updateUser } = require("../utils/db");

module.exports = async ({ user, args }) => {

    const charId = args[0];

    if (!charId) {
        return {
            reply: "❌ Usage: .character <id>\nExample: .character gojo"
        };
    }

    const character = getCharacter(charId);

    if (!character) {
        return {
            reply: "❌ Character not found."
        };
    }

    // 🧠 EQUIP CHARACTER (CLEAN FIX)
    updateUser(user.id, {
        character: {
            id: character.id,
            name: character.name,
            hp: character.hp,
            ce: character.ce,
            strength: character.strength,
            defense: character.defense,
            speed: character.speed,
            skills: character.skills,
            rarity: character.rarity
        }
    });

    return {
        reply: `
🎴 *CHARACTER EQUIPPED SUCCESSFULLY*

👤 Name: ${character.name}
⭐ Rarity: ${character.rarity.toUpperCase()}

❤️ HP: ${character.hp}
⚡ CE: ${character.ce}
💥 STR: ${character.strength}
🛡 DEF: ${character.defense}
⚡ SPEED: ${character.speed}

🔥 This character now affects ALL battles!
`
    };
};