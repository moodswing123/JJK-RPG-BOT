const { getCharacter } = require("../utils/characters");

module.exports = async ({ user }) => {

    const formatList = (arr) => {
        if (!arr || arr.length === 0) return "None";
        return arr.join(", ");
    };

    // 🎴 Convert character IDs → readable names (IMPORTANT FIX)
    const formatCharacters = (arr) => {
        if (!arr || arr.length === 0) return "None";

        return arr.map(id => {
            const char = getCharacter(id);
            return char ? char.name : id;
        }).join(", ");
    };

    const inventoryText = `
🎒 *INVENTORY*

👤 Name: ${user.name}

────────────────────

🎴 CHARACTERS
${formatCharacters(user.characters)}

────────────────────

🗡️ TOOLS
${formatList(user.tools)}

────────────────────

👕 SKINS
${formatList(user.skins)}

────────────────────

📦 ITEMS
${formatList(user.items)}

────────────────────

🏆 TITLES
${formatList(user.titles)}

────────────────────

⚙️ EQUIPPED LOADOUT
👤 Character: ${user.character?.name || "None"}
🗡️ Tool: ${user.equippedTool || "None"}
🏷️ Title: ${user.equippedTitle || "None"}

────────────────────

📊 QUICK STATS
❤️ HP: ${user.hp}
⚡ CE: ${user.ce}
💰 Yen: ${user.yen}

────────────────────

📌 Use .shop to buy items
📌 Use .pull to get characters
📌 Use .character <id> to equip
`;

    return {
        reply: inventoryText,
        cooldown: 3
    };
};