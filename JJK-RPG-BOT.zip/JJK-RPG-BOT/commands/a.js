const { attack, getBattle, endBattle, findBattleByUser } = require("../handlers/battleHandler");
const { updateUser } = require("../utils/db");

module.exports = async ({ user, args }) => {

    const skillName = args.join(" ");

    if (!skillName) {
        return {
            reply: "❌ Usage: .a <skill name>"
        };
    }

    // 🔍 Find battle using real user ID (FIXED RELIABILITY)
    const found = findBattleByUser(user.id);

    if (!found) {
        return {
            reply: "❌ You are not in an active battle."
        };
    }

    const { battleId, battle } = found;

    const skill = {
        name: skillName,
        damage: 120
    };

    // ⚔️ Execute attack
    const result = attack(battleId, user.id, skill);

    if (result.error) {
        return {
            reply: result.error
        };
    }

    // 🏆 HANDLE WIN CONDITION (IMPORTANT FIX)
    if (result.winner) {

        const winnerId = result.winner;
        const loserId = result.loser;

        // 🧠 GET ACTUAL USERS FROM BATTLE
        const winner = battle.players.p1.id === winnerId
            ? battle.players.p1
            : battle.players.p2;

        const loser = battle.players.p1.id === loserId
            ? battle.players.p1
            : battle.players.p2;

        // 💾 SAVE WINNER DATA
        updateUser(winnerId, {
            wins: (winner.wins || 0) + 1,
            yen: (winner.yen || 0) + 500
        });

        // 💀 SAVE LOSER DATA
        updateUser(loserId, {
            losses: (loser.losses || 0) + 1
        });

        // 🧹 END BATTLE
        endBattle(battleId);

        return {
            reply: `
🏆 *BATTLE FINISHED!*

👑 Winner: ${winnerId.split("@")[0]}
💀 Loser: ${loserId.split("@")[0]}

💰 Reward: +500 yen to winner
`,
            cooldown: 5
        };
    }

    // ⚔️ NORMAL ATTACK RESPONSE
    return {
        reply: `
⚔️ *ATTACK EXECUTED*

💥 Skill: ${skill.name}
🩸 Damage: ${result.damage}
${result.crit ? "🔥 CRITICAL HIT!" : ""}

❤️ Enemy HP: ${result.defenderHp}
🔁 Next Turn: ${result.nextTurn.split("@")[0]}
`,
        cooldown: 3
    };
};