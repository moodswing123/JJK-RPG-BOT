const { getUser } = require("../utils/db");
const fs = require("fs");

const DB_PATH = "./data/users.json";

function loadDB() {
    return JSON.parse(fs.readFileSync(DB_PATH));
}

module.exports = async () => {

    const db = loadDB();

    const users = Object.values(db);

    // 🏆 SORT BY RP
    const sorted = users.sort((a, b) => (b.rp || 0) - (a.rp || 0));

    const top = sorted.slice(0, 10);

    let text = `🏆 *GLOBAL LEADERBOARD*\n\n`;

    top.forEach((user, index) => {

        const medal =
            index === 0 ? "🥇" :
            index === 1 ? "🥈" :
            index === 2 ? "🥉" : "🏅";

        text += `
${medal} ${index + 1}. ${user.name}
⭐ Rank: ${user.rank}
📊 RP: ${user.rp}
⚔️ Wins: ${user.wins || 0} | 💀 Losses: ${user.losses || 0}
────────────────────
`;
    });

    return {
        reply: text,
        cooldown: 10
    };
};