const { getUser } = require("../utils/db");
const { challenge } = require("../handlers/battleHandler");

module.exports = async ({ user, args, message }) => {

    // 📌 Extract mentioned user from WhatsApp message
    let opponentId = null;

    const msg = message.message;

    // 🔍 Proper WhatsApp mention detection
    if (msg?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        opponentId = msg.extendedTextMessage.contextInfo.mentionedJid[0];
    }

    // 🔍 Fallback: manual input
    if (!opponentId && args[0]) {
        opponentId = args[0].replace("@", "") + "@s.whatsapp.net";
    }

    // ❌ No opponent found
    if (!opponentId) {
        return {
            reply: "❌ You must tag a valid player.\nExample: .ch @user"
        };
    }

    // 🧠 Get REAL users from database (PHASE 2 FIX)
    const challenger = user;
    const opponent = getUser(opponentId);

    // ❌ Self challenge check
    if (challenger.id === opponent.id) {
        return {
            reply: "❌ You cannot challenge yourself."
        };
    }

    // ⚔️ Start battle using real users
    const result = challenge(challenger, opponent);

    return {
        reply: `
⚔️ *BATTLE CHALLENGE STARTED!*

👤 Challenger: ${challenger.name}
👤 Opponent: ${opponent.name}

🔥 ${result.message}

📌 Use .a <skill> to attack
📌 Turn-based PvP enabled
📌 First turn: ${challenger.name}
`,
        cooldown: 10
    };
};