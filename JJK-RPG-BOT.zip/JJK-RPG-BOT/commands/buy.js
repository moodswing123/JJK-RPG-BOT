const items = require("../data/items.json");
const shops = require("../data/shops.json");

module.exports = async ({ user, args }) => {

    const itemName = args.join(" ").toLowerCase();

    if (!itemName) {
        return {
            reply: "❌ Usage: .buy <item name>"
        };
    }

    // 🔍 Find item in database
    const item = items.find(i =>
        i.name.toLowerCase() === itemName ||
        i.id.toLowerCase() === itemName
    );

    if (!item) {
        return {
            reply: "❌ Item not found."
        };
    }

    // 💰 Check balance
    if (user.yen < item.price) {
        return {
            reply: `❌ Not enough yen!\n💰 You need ${item.price - user.yen} more yen.`
        };
    }

    // 💸 Deduct money
    user.yen -= item.price;

    // 🎒 Add to inventory
    if (item.type === "Consumable" || item.type === "Material" || item.type === "Special") {
        user.items.push(item.id);
    } else if (item.type === "Tool") {
        user.tools.push(item.id);
    } else if (item.type === "Relic") {
        user.items.push(item.id);
    } else {
        user.items.push(item.id);
    }

    return {
        reply: `
✅ *PURCHASE SUCCESSFUL*

📦 Item: ${item.name}
💰 Price: ${item.price} yen

🎒 Added to your inventory!

📌 Use .inv to view items
`,
        cooldown: 3
    };
};