const items = require("../data/items.json");

module.exports = async ({ user, args }) => {

    const itemName = args.join(" ").toLowerCase();

    if (!itemName) {
        return {
            reply: "❌ Usage: .use <item name>"
        };
    }

    // 🔍 Find item in inventory
    const itemIndex = user.items.findIndex(i =>
        i.toLowerCase() === itemName
    );

    if (itemIndex === -1) {
        return {
            reply: "❌ You don't own this item."
        };
    }

    const itemId = user.items[itemIndex];

    // 🔍 Get item data
    const item = items.find(i => i.id === itemId);

    if (!item) {
        return {
            reply: "❌ Item data not found."
        };
    }

    // 🧪 Apply effects
    let resultText = `🧪 *ITEM USED*\n\n📦 ${item.name}\n`;

    switch (item.effect) {

        case "heal_hp":
            user.hp = Math.min(user.maxHp, user.hp + item.value);
            resultText += `❤️ HP restored by ${item.value}`;
            break;

        case "heal_full":
            user.hp = user.maxHp;
            user.ce = user.maxCe;
            resultText += `❤️ Full HP & CE restored!`;
            break;

        case "boost_ce":
            user.ce = Math.min(user.maxCe, user.ce + item.value);
            resultText += `⚡ CE boosted by ${item.value}`;
            break;

        case "xp_boost":
            user.xpBoost = Date.now() + (item.value * 60000);
            resultText += `⭐ XP boost activated!`;
            break;

        case "luck_boost":
            user.luck += item.value;
            resultText += `🍀 Luck increased by ${item.value}`;
            break;

        case "revive":
            if (user.hp > 0) {
                return {
                    reply: "❌ You can only use revive when downed."
                };
            }
            user.hp = Math.floor(user.maxHp * 0.5);
            resultText += `💀 You have been revived!`;
            break;

        default:
            return {
                reply: "❌ This item cannot be used."
            };
    }

    // 🗑️ Remove item after use (if consumable)
    if (item.type === "Consumable" || item.type === "Special") {
        user.items.splice(itemIndex, 1);
    }

    return {
        reply: resultText,
        cooldown: 3
    };
};