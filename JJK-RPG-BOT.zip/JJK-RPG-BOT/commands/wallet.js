module.exports = async ({ user }) => {

    const walletText = `
💰 *SORCERER WALLET*

👤 Name: ${user.name}

────────────────────

💵 BALANCE
💴 Yen: ${user.yen}

────────────────────

📊 INCOME STATUS
🏆 Wins: ${user.wins}
💀 Losses: ${user.losses}
🔥 Streak: ${user.streak}

────────────────────

🎁 NOTES
- Earn yen from PvP battles
- Complete quests for rewards
- Sell items in shop system (coming soon)

────────────────────

📌 Tip: Use .shop to spend your money wisely
`;

    return {
        reply: walletText,
        cooldown: 3
    };
};