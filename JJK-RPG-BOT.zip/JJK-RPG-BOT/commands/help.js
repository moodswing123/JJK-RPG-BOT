module.exports = async () => {

    return {
        reply: `
📖 *JUJUTSU KAISEN RPG BOT*

━━━━━━━━━━━━━━━━━━

⚔️ *BATTLE SYSTEM*
.ch @user - Challenge player
.a <skill> - Attack in battle
.domain <name> - Activate Domain Expansion

━━━━━━━━━━━━━━━━━━

💰 *ECONOMY*
.wallet - Check your yen
.shop - View available shops
.buy <item> - Purchase items
.use <item> - Use consumables

━━━━━━━━━━━━━━━━━━

🎒 *PROGRESSION*
.profile - View stats
.inv - Inventory system
.level up automatically through XP

━━━━━━━━━━━━━━━━━━

🧠 *COMBAT FEATURES*
- Turn-based PvP battles
- Cursed Energy system
- Status effects (burn, stun, bleed)
- Domain Expansion abilities
- Critical hit system

━━━━━━━━━━━━━━━━━━

🏆 *GOAL*
Become a Special Grade Sorcerer
Unlock Gojo or Sukuna
Dominate PvP battles

━━━━━━━━━━━━━━━━━━

📌 Type commands with "." prefix
Example: .profile
`
    };
};