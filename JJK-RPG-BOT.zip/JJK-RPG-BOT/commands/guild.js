const {
    createGuild,
    joinGuild,
    leaveGuild,
    getGuild
} = require("../utils/guilds");

const { updateUser } = require("../utils/db");

module.exports = async ({ user, args }) => {

    const action = args[0];

    // 🏰 CREATE
    if (action === "create") {

        const name = args.slice(1).join(" ");

        if (!name) {
            return { reply: "❌ Provide guild name." };
        }

        const id = createGuild(user, name);

        updateUser(user.id, {
            guild: id,
            guildRole: "leader"
        });

        return {
            reply: `🏰 Guild created!\nName: ${name}\nID: ${id}`
        };
    }

    // ➕ JOIN
    if (action === "join") {

        const id = args[1];

        const res = joinGuild(user, id);

        if (res.error) return { reply: res.error };

        updateUser(user.id, {
            guild: id,
            guildRole: "member"
        });

        return { reply: "✅ Joined guild!" };
    }

    // 🚪 LEAVE
    if (action === "leave") {

        const id = user.guild;

        if (!id) return { reply: "❌ Not in a guild." };

        const res = leaveGuild(user, id);

        if (res.error) return { reply: res.error };

        updateUser(user.id, {
            guild: null,
            guildRole: null
        });

        return { reply: "🚪 Left guild." };
    }

    // 📊 VIEW
    if (action === "view") {

        const id = args[1];

        const guild = getGuild(id);

        if (!guild) return { reply: "❌ Guild not found." };

        return {
            reply: `
🏰 *GUILD INFO*

Name: ${guild.name}
Leader: ${guild.owner}
Members: ${guild.members.length}
Level: ${guild.level}
XP: ${guild.xp}

Wins: ${guild.wins} | Losses: ${guild.losses}
`
        };
    }

    return {
        reply: `
🏰 Guild Commands:

.guild create <name>
.guild join <id>
.guild leave
.guild view <id>
`
    };
};