module.exports = async ({ user }) => {

    const profileText = `
⚔️ *SORCERER PROFILE*

👤 Name: ${user.name}
🏷️ Title: ${user.equippedTitle || "None"}
🏯 Clan: ${user.clan}

────────────────────

📊 STATS
⭐ Level: ${user.level}
✨ XP: ${user.xp}
💰 Yen: ${user.yen}

❤️ HP: ${user.hp}/${user.maxHp}
⚡ CE: ${user.ce}/${user.maxCe}

💪 Strength: ${user.strength}
🛡️ Defense: ${user.defense}
⚡ Speed: ${user.speed}
🍀 Luck: ${user.luck}

────────────────────

⚔️ BATTLE RECORD
🏆 Wins: ${user.wins}
💀 Losses: ${user.losses}
🔥 Streak: ${user.streak}

────────────────────

🎒 INVENTORY
👤 Characters: ${user.characters.length}
🗡️ Tools: ${user.tools.length}
👕 Skins: ${user.skins.length}
🏆 Titles: ${user.titles.length}

────────────────────

🧠 Status: ${user.status.length > 0 ? user.status.join(", ") : "Normal"}

────────────────────

📌 Use .help to see commands
`;

    return {
        reply: profileText,
        cooldown: 3
    };
};