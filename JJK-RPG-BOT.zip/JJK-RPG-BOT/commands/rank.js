module.exports = async ({ user }) => {

    return {
        reply: `
🏆 *RANK PROFILE*

👤 Name: ${user.name}

────────────────

⭐ Rank: ${user.rank}
📊 RP: ${user.rp}

────────────────

⚔️ Wins: ${user.wins || 0}
💀 Losses: ${user.losses || 0}

────────────────

🔥 Keep fighting to rank up!
`
    };
};