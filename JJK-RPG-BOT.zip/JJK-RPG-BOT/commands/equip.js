const { getCharacter } = require("../utils/characters");
const { updateUser } = require("../utils/db");

module.exports = async ({ user, args }) => {

    const type = args[0]; // character / tool / title
    const id = args[1];

    if (!type || !id) {
        return {
            reply: `
❌ Usage:
.equip character <id>
.equip tool <id>
.equip title <id>
`
        };
    }

    // ⚙️ CHARACTER EQUIP
    if (type === "character") {

        const character = getCharacter(id);

        if (!character) {
            return { reply: "❌ Character not found." };
        }

        updateUser(user.id, {
            character: {
                id: character.id,
                name: character.name,
                hp: character.hp,
                ce: character.ce,
                strength: character.strength,
                defense: character.defense,
                speed: character.speed,
                skills: character.skills,
                rarity: character.rarity
            }
        });

        return {
            reply: `
🎴 *CHARACTER EQUIPPED*

👤 ${character.name}
⭐ ${character.rarity.toUpperCase()}

🔥 Ready for battle!
`
        };
    }

    // 🗡️ TOOL EQUIP
    if (type === "tool") {

        const tools = user.tools || [];

        if (!tools.includes(id)) {
            return { reply: "❌ You don't own this tool." };
        }

        updateUser(user.id, {
            equippedTool: id
        });

        return {
            reply: `🗡️ Tool equipped: ${id}`
        };
    }

    // 🏷️ TITLE EQUIP
    if (type === "title") {

        const titles = user.titles || [];

        if (!titles.includes(id)) {
            return { reply: "❌ You don't own this title." };
        }

        updateUser(user.id, {
            equippedTitle: id
        });

        return {
            reply: `🏷️ Title equipped: ${id}`
        };
    }

    return {
        reply: "❌ Invalid equip type. Use character/tool/title."
    };
};