const {
    createTournament,
    joinTournament,
    startTournament,
    getTournament
} = require("../utils/tournaments");

module.exports = async ({ user, args }) => {

    const action = args[0];
    const id = args[1];

    // 🏆 CREATE
    if (action === "create") {

        const tourneyId = createTournament("Ultimate Battle");

        return {
            reply: `🏆 Tournament created!\nID: ${tourneyId}`
        };
    }

    // ➕ JOIN
    if (action === "join") {

        const res = joinTournament(id, user);

        if (res.error) return { reply: res.error };

        return { reply: "✅ Joined tournament!" };
    }

    // ⚔️ START
    if (action === "start") {

        const res = startTournament(id);

        if (res.error) return { reply: res.error };

        return {
            reply: `⚔️ Tournament started!\n\nBrackets ready!`
        };
    }

    // 📊 VIEW
    if (action === "view") {

        const t = getTournament(id);

        if (!t) return { reply: "❌ Not found" };

        return {
            reply: `
🏆 *TOURNAMENT*

Name: ${t.name}
Status: ${t.status}
Players: ${t.players.length}
Round: ${t.round}

Winner: ${t.winner || "TBD"}
`
        };
    }

    return {
        reply: `
❌ Usage:
.tournament create
.tournament join <id>
.tournament start <id>
.tournament view <id>
`
    };
};