const { activateDomain, applyDomainBoost } = require("../utils/domain");
const { getBattle } = require("../handlers/battleHandler");

module.exports = async ({ user, args }) => {

    const domainName = args.join("_").toLowerCase();

    if (!domainName) {
        return {
            reply: `
❌ Usage: .domain <name>

🌌 Available Domains:
- infinite_void
- malevolent_shrine
- hollow_purple_domain
`
        };
    }

    // ⚔️ Check if user is in battle
    let battleId = null;

    for (const [id, battle] of global.activeBattles || []) {
        if (battle.players.p1.id === user.id || battle.players.p2.id === user.id) {
            battleId = id;
            break;
        }
    }

    if (!battleId) {
        return {
            reply: "❌ You can only use Domain Expansion inside a battle."
        };
    }

    const battle = getBattle(battleId);

    if (!battle) {
        return {
            reply: "❌ No active battle found."
        };
    }

    // 🌌 Activate domain
    const result = activateDomain(user, domainName);

    if (!result.success) {
        return {
            reply: result.message
        };
    }

    // ⚔️ Apply domain effects to battle
    battle.domain = result.effect;

    return {
        reply: `
🌌 *DOMAIN EXPANSION ACTIVATED!*

⚡ ${result.message}

🔥 Damage Boost: +${result.effect.damageBoost * 100}%
${result.effect.status ? `💀 Status Applied: ${result.effect.status.name}` : ""}

⚔️ Battlefield has changed!

📌 Effects are now active in battle
`,
        cooldown: 10
    };
};