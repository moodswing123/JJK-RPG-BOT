const { pullCharacter } = require("../utils/gacha");
const { updateUser } = require("../utils/db");

module.exports = async ({ user }) => {

    const cost = 500;

    // 💰 check balance
    if (user.yen < cost) {
        return {
            reply: "❌ Not enough yen. You need 500 yen to pull."
        };
    }

    const character = pullCharacter();

    // 💸 deduct money
    const newYen = user.yen - cost;

    // 📦 add to inventory
    const updatedChars = user.characters || [];
    updatedChars.push(character.id);

    updateUser(user.id, {
        yen: newYen,
        characters: updatedChars
    });

    return {
        reply: `
🎰 *GACHA RESULT*

👤 You pulled: ${character.name}
⭐ Rarity: ${character.pulledRarity.toUpperCase()}

💥 Stats:
❤️ HP: ${character.hp}
⚡ CE: ${character.ce}
💥 STR: ${character.strength}

💰 -500 yen

📦 Added to your inventory!
`
    };
};