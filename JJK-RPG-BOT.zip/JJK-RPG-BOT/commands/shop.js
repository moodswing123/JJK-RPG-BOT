const fs = require("fs");

// 📦 Load shop data
const shops = require("../data/shops.json");

// 📦 Load items data
const items = require("../data/items.json");

module.exports = async ({ user, args }) => {

    const shopName = args[0]?.toLowerCase();

    // 🏪 Show all shops
    if (!shopName) {

        const shopList = shops.map(s => `🏪 ${s.name} - .shop ${s.id}`).join("\n");

        return {
            reply: `
🛒 *AVAILABLE SHOPS*

${shopList}

────────────────────

📌 Use .shop <shop_id> to view items
`
        };
    }

    // 🔍 Find shop
    const shop = shops.find(s => s.id === shopName);

    if (!shop) {
        return {
            reply: "❌ Shop not found."
        };
    }

    // 🛍️ Build shop inventory
    let shopItems = [];

    // Items
    if (shop.items?.length) {
        shop.items.forEach(id => {
            const item = items.find(i => i.id === id);
            if (item) shopItems.push(item);
        });
    }

    // Tools (placeholder system for now)
    if (shop.tools?.length) {
        shop.tools.forEach(tool => {
            shopItems.push({
                id: tool,
                name: tool.replace(/_/g, " "),
                type: "Tool",
                rarity: "Unknown",
                price: 50000
            });
        });
    }

    // 🧾 If no items
    if (shopItems.length === 0) {
        return {
            reply: "❌ This shop is currently empty."
        };
    }

    // 🛒 Format shop display
    let text = `🛒 *${shop.name.toUpperCase()}*\n\n`;

    shopItems.forEach((item, index) => {
        text += `
${index + 1}. ${item.name}
💰 Price: ${item.price} yen
📦 Type: ${item.type}
📊 Rarity: ${item.rarity}
`;
    });

    text += `\n────────────────────\n📌 Use .buy <item_name> (coming next)`;

    return {
        reply: text,
        cooldown: 3
    };
};